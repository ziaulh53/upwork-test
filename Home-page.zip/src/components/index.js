export { default as Header } from './Navbar';
export { default as HeroSection } from "./HeroSection";
export { default as Faq } from "./Faq";
export { default as Footer } from "./Footer";
export { default as Service } from "./Service";
export { default as WorkCriteria } from "./WorkCriteria";
