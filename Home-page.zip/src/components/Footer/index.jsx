import React from "react";

const Footer = () => (
  <section id="footer">
    <div className="logo text-center">
      <img src="./img/logo-footer.png" alt="" />
    </div>
  </section>
);

export default Footer;
