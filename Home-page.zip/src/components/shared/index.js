export { default as SharedBtn } from "./Button";
export { default as Title } from "./Title";
